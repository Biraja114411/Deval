describe("Transform functions", function() {
    it("SumVector", function() {
        var vector = SumVector({x:0, y: 0, z:0},{x:0, y:0, z:0});
        expect(Object.assign({}, vector)).toEqual(Object.assign({}, {x: 0, y: 0, z: 0}));
    });
   
    it("SubVector", function() {
        var vector = SubVector({x:0, y: 0, z:0},{x:0, y:0, z:0});
        expect(Object.assign({}, vector)).toEqual(Object.assign({}, {x: 0, y: 0, z: 0}));
    });
   /*  it("GetWorldPosition", function() {
        let entity = {position: {x: 0, y: 0, z: 0}};
        let pos = entity.getAttribute('position');
        var vector = GetWorldPosition(entity);
        expect(Object.assign({}, vector)).toEqual(pos);
    });
     it("GetLocalPosition", function() {
        var vector = GetLocalPosition({x:0, y: 0, z:0},{x:0, y:0, z:0});
        expect(Object.assign({}, vector)).toEqual({x: 0, y: 0, z: 0});
    }); */
   
});